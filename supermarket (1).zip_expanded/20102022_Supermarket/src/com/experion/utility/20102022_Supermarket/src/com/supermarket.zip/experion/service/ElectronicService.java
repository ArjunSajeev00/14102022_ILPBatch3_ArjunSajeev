package com.experion.service;

public interface ElectronicService {
	
	public abstract void ProductRepair();

	public abstract void warrantyReplacement();
	

}
