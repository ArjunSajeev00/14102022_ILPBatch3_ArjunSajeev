package com.experion.service;

public interface FabricService {

	public abstract void productExchange();


}
